package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.classes.MySQLCon;
import com.classes.Queries;

/**
 * Servlet implementation class FriendServlet
 */
@WebServlet("/FriendServlet")
public class FriendServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			PreparedStatement statement = MySQLCon.getConnection().prepareStatement(Queries.queryForShowFriends());
			
			statement.setInt(1, Integer.parseInt(request.getParameter("empRegId")));
			statement.setString(2, request.getParameter("empOrganization"));
			ResultSet result = statement.executeQuery();
			PrintWriter out = response.getWriter();
			request.setAttribute("friendList", result);
	        getServletContext().getRequestDispatcher("/friend.jsp").include(request, response);
		}

		catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
